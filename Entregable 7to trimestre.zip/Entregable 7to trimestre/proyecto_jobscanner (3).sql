-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-03-2022 a las 18:16:53
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto_jobscanner`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `area`
--

CREATE TABLE `area` (
  `idarea` int(11) NOT NULL,
  `nombre_area` varchar(40) NOT NULL,
  `zona_area` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `area`
--

INSERT INTO `area` (`idarea`, `nombre_area`, `zona_area`) VALUES
(1, 'operaciones', 'norte'),
(2, 'gestion humana', 'central'),
(3, 'administrativa', 'sur'),
(4, 'Contabilidad', 'sección 1'),
(10, 'servicios varios', 'norte'),
(18, 'Nueva', 'sur'),
(20, 'zzxc', 'zonaaaa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `area_maquina`
--

CREATE TABLE `area_maquina` (
  `idareamaquina` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `idmaquina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `area_maquina`
--

INSERT INTO `area_maquina` (`idareamaquina`, `nombre`, `idmaquina`) VALUES
(1, 'seccion1', 1),
(2, 'seccion2', 2),
(3, 'seccion3', 3),
(4, 'seccion4', 4),
(8, 'seccion8', 5),
(12, 'seccion4', 12),
(13, 'seccion11', 2),
(14, 'aqaqaqaqaqaq', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargo`
--

CREATE TABLE `cargo` (
  `idcargo` int(11) NOT NULL,
  `nombre_cargo` varchar(40) NOT NULL,
  `idarea` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cargo`
--

INSERT INTO `cargo` (`idcargo`, `nombre_cargo`, `idarea`) VALUES
(1, 'secretaria', 2),
(2, 'gerente', 3),
(3, 'coordinador', 3),
(4, 'operario', 1),
(5, 'mantenimiento', 1),
(19, 'aseo', 2),
(44, 'operador', 1),
(50, 'wqwqwqwq', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documentos`
--

CREATE TABLE `documentos` (
  `iddocumentos` int(11) NOT NULL,
  `nombre_documento` varchar(60) NOT NULL,
  `url` varchar(255) NOT NULL,
  `idmaquina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `documentos`
--

INSERT INTO `documentos` (`iddocumentos`, `nombre_documento`, `url`, `idmaquina`) VALUES
(2, 'manual de operacion', 'www.rrr.com', 2),
(3, 'elementos de proteccion personal', 'www.bvv.com', 3),
(6, 'GTC 46', 'www.asa.com', 4),
(12, 'normativa tecnica colombiana', '../Documentos/paisaje natural.jpeg', 3),
(16, 'normativa tecnica colombiana kk', '../Documentos/loco.jpg', 16),
(17, 'GTC 45', '../Documentos/linea de tiempo.png', 18),
(18, 'GTC 46', '../Documentos/invierno.jpg', 18),
(19, 'GTC 4444', '../Documentos/ESTANDARES DE SEGURIDAD ESMERIL (2).pdf', 10),
(23, 'procedimiento para empleados nuevos', '../Documentos/comprobante_de_pago (13).pdf', 22);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `idempleado` int(11) NOT NULL,
  `nombre_empleado` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `genero` varchar(25) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `salario` int(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `idcargo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`idempleado`, `nombre_empleado`, `apellido`, `genero`, `direccion`, `salario`, `email`, `fecha_nacimiento`, `idcargo`) VALUES
(2, 'carlos', 'restrepo', 'M', 'cra 22 f 555', 120000, 'cr@hotmail.com', '1990-11-08', 4),
(3, 'sebastian', 'rivera', 'M', 'cr 2 a 55', 2000000, 'sr@hotmail.com', '1980-11-13', 4),
(4, 'Jhosef', 'Higuita', 'M', 'av 77 c 81', 890000, 'jh@gmail.com', '1992-06-22', 4),
(6, 'Rubi', 'Guzman', 'F', 'cra 10 a 12 c 15', 890000, 'rg@gmail.com', '1979-01-11', 1),
(8, 'Federico', 'Velez', 'M', 'cr 12 10 c 5', 1200000, 'fede@hotmail.com', '1981-08-17', 4),
(10, 'Emiliana', 'Sanchez', 'F', 'cra 1 a 5 a 65', 7000000, 'emisa@hotmail.com', '1999-05-10', 3),
(29, 'Santiago', 'Torres', 'M', 'cra 64 104 b 7', 1200000, 'jara1497@gmail.com', '1995-01-10', 4),
(33, 'Luis', 'Hernandez', 'M', 'cra 60 # 67 - 37', 1400000, 'hel´ping@gmail.com', '1998-11-11', 4),
(40, 'Sebastian', 'Munera', 'M', 'Tv 5 # 74 30', 5000000, 'fisho@gmail.com', '1996-11-16', 4),
(41, 'TORNOooo', 'ssfsf', 'dsfd', 'sdfdf', 0, 'dfdf', '0000-00-00', 4),
(42, 'sdsadsa', 'ssfsfdsdsdsad', 'dsfdkkkkk', 'sdfdfsadsdsdd', 0, 'dfdffdgkkkkk', '0000-00-00', 4),
(43, 'kkkkkkkkkkkk', 'ssfsfdsdsdsad', 'dsfdkkkkk', 'sdfdfsadsdsdd', 0, 'dfdffdgkkkkk', '0000-00-00', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventoscalendar`
--

CREATE TABLE `eventoscalendar` (
  `id` int(11) NOT NULL,
  `evento` varchar(250) CHARACTER SET utf8mb4 NOT NULL,
  `color_evento` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `fecha_inicio` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `fecha_fin` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `idarea` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `eventoscalendar`
--

INSERT INTO `eventoscalendar` (`id`, `evento`, `color_evento`, `fecha_inicio`, `fecha_fin`, `idarea`) VALUES
(51, 'Mi Primera Prueba', 'teal', '2021-07-07', '2021-07-08', 3),
(52, 'Mi Segunda Prueba', 'amber', '2021-07-17', '2021-07-18', 3),
(53, 'Mi Tercera Prueba', 'orange', '2021-07-03', '2021-07-04', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inicio_sesion`
--

CREATE TABLE `inicio_sesion` (
  `idinicio` int(11) NOT NULL,
  `usuario` varchar(40) NOT NULL,
  `contraseña` varchar(40) NOT NULL,
  `idempleado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `inicio_sesion`
--

INSERT INTO `inicio_sesion` (`idinicio`, `usuario`, `contraseña`, `idempleado`) VALUES
(1, 'carrestre', 'car123', 2),
(2, 'seriver', 'rivera97', 3),
(3, 'higuita', 'jhosef123456', 4),
(10, 'santiago', '12345', 29),
(11, 'luis', '12345', 33),
(14, 'meduso', '123456', 40),
(16, 'soto789', '123456', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mantenimiento`
--

CREATE TABLE `mantenimiento` (
  `idmantenimiento` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `idempleado` int(11) NOT NULL,
  `idmaquina` int(11) NOT NULL,
  `idtipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `mantenimiento`
--

INSERT INTO `mantenimiento` (`idmantenimiento`, `fecha`, `descripcion`, `idempleado`, `idmaquina`, `idtipo`) VALUES
(1, '2021-04-06', 'Maquina con problemas electricos, se prende y se apaga', 2, 2, 1),
(2, '2021-09-10', 'Maquina con ruidos no convencionales', 4, 5, 2),
(4, '2021-12-05', 'la maquina se sobrecargo y ya no prende', 6, 6, 0),
(8, '0000-00-00', 'El cable de la luz se dañó de la troqueladora', 8, 6, 0),
(9, '2022-03-10', 'se quemó el suich', 6, 18, 0),
(10, '1995-01-10', 'pacho se quemo el pie', 4, 12, 0),
(11, '2022-03-17', 'motor con ruido no convencionalaaaaaa', 40, 28, 0),
(13, '2022-04-02', 'error en el panel de control', 10, 7, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `maquinas`
--

CREATE TABLE `maquinas` (
  `idmaquina` int(11) NOT NULL,
  `nombre_maquina` varchar(50) NOT NULL,
  `marca` varchar(100) NOT NULL,
  `peso` varchar(25) NOT NULL,
  `color` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `maquinas`
--

INSERT INTO `maquinas` (`idmaquina`, `nombre_maquina`, `marca`, `peso`, `color`) VALUES
(1, 'taladro de banco', 'DEWALT', '56 kg', 'negro'),
(2, 'fresadora', 'HELLER', '2900 Kg', 'blanco'),
(3, 'rectificadora', 'HELLER', '5800 kg', 'negro'),
(4, 'sierra sin fin', 'TRUPER', '100 KG', 'azul'),
(5, 'torno convencional', 'KNUTH', '500 kg', 'verde'),
(6, 'troqueladora', 'ATOM', '200 kg', 'negro'),
(7, 'inyectoras', 'YIZUMI', '300 kg', 'negro'),
(8, 'puntilleras', 'YIZUMI', '90 kg', 'blanco'),
(9, 'roladoras', 'KNUTH', '7750 kg', 'azul'),
(10, 'pulidora', 'DEWALT', '150 kg', 'negro'),
(11, 'tronzadora', 'DEWALT', '30 kg', 'rojo'),
(12, 'mortajadora', 'SACEM M-200', '650 kg', 'blanco'),
(13, 'vibradoras', 'Engineering', '70 kg', 'blanco'),
(14, 'centrifugas', 'SITEC', '500 kg', 'negro'),
(15, 'mandriladora', 'SIRIO S', '1200 kg', 'gris'),
(16, 'cizalla', 'CNC NARGESA', '400 kg', 'negro'),
(17, 'prensa hidraulica', 'TMG ', '550 kg', 'azul'),
(18, 'Calentadora recalcadora', 'MANEK', '1600 kg', 'verde'),
(22, 'TORNO', 'HQ', '52 kg', 'AZUL'),
(28, 'prensa', 'xt12', '560 kg ', 'negrooo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulos`
--

CREATE TABLE `modulos` (
  `idmodulos` int(11) NOT NULL,
  `descripción` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `modulos`
--

INSERT INTO `modulos` (`idmodulos`, `descripción`) VALUES
(1, 'Administracion personal'),
(2, 'Administracion Herramientas'),
(3, 'Modulo general');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permisosempleado`
--

CREATE TABLE `permisosempleado` (
  `idcargo` int(11) NOT NULL,
  `idmodulos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `permisosempleado`
--

INSERT INTO `permisosempleado` (`idcargo`, `idmodulos`) VALUES
(2, 1),
(2, 2),
(2, 3),
(4, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_matenimiento`
--

CREATE TABLE `tipo_matenimiento` (
  `idtipo` int(11) NOT NULL,
  `nombre_mantenimiento` varchar(100) NOT NULL,
  `idmantenimiento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipo_matenimiento`
--

INSERT INTO `tipo_matenimiento` (`idtipo`, `nombre_mantenimiento`, `idmantenimiento`) VALUES
(1, 'mantenimiento preventivo', 1),
(2, 'mantenimiento correctivo', 2),
(9, 'mantenimiento operativo', 4),
(12, 'cambio de cable', 8),
(14, 'cambio del suiche, se realizará en el transcurso del dia', 9),
(15, 'Cambio del motorRRRR', 11),
(17, 'se reporta de manera inmediata con el personal de mantenimiento', 13);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista1`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista1` (
`salario` int(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista2`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista2` (
`nombre_empleado` varchar(30)
,`nombre_cargo` varchar(40)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista1`
--
DROP TABLE IF EXISTS `vista1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista1`  AS SELECT `empleado`.`salario` AS `salario` FROM (`empleado` join `cargo` on(`empleado`.`idempleado` = `cargo`.`idcargo`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista2`
--
DROP TABLE IF EXISTS `vista2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista2`  AS SELECT `empleado`.`nombre_empleado` AS `nombre_empleado`, `cargo`.`nombre_cargo` AS `nombre_cargo` FROM (`empleado` join `cargo`) WHERE `cargo`.`idcargo` = `empleado`.`idcargo` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`idarea`);

--
-- Indices de la tabla `area_maquina`
--
ALTER TABLE `area_maquina`
  ADD PRIMARY KEY (`idareamaquina`),
  ADD KEY `idmaquina` (`idmaquina`);

--
-- Indices de la tabla `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`idcargo`),
  ADD KEY `idarea` (`idarea`);

--
-- Indices de la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD PRIMARY KEY (`iddocumentos`),
  ADD KEY `idmaquina` (`idmaquina`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`idempleado`),
  ADD KEY `idcargo` (`idcargo`);

--
-- Indices de la tabla `eventoscalendar`
--
ALTER TABLE `eventoscalendar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idarea` (`idarea`);

--
-- Indices de la tabla `inicio_sesion`
--
ALTER TABLE `inicio_sesion`
  ADD PRIMARY KEY (`idinicio`),
  ADD KEY `idempleado` (`idempleado`);

--
-- Indices de la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  ADD PRIMARY KEY (`idmantenimiento`),
  ADD KEY `idempleado` (`idempleado`),
  ADD KEY `idtipo` (`idtipo`),
  ADD KEY `idmaquina` (`idmaquina`);

--
-- Indices de la tabla `maquinas`
--
ALTER TABLE `maquinas`
  ADD PRIMARY KEY (`idmaquina`);

--
-- Indices de la tabla `modulos`
--
ALTER TABLE `modulos`
  ADD PRIMARY KEY (`idmodulos`);

--
-- Indices de la tabla `permisosempleado`
--
ALTER TABLE `permisosempleado`
  ADD KEY `idmodulos` (`idmodulos`),
  ADD KEY `idempleado` (`idcargo`);

--
-- Indices de la tabla `tipo_matenimiento`
--
ALTER TABLE `tipo_matenimiento`
  ADD PRIMARY KEY (`idtipo`),
  ADD KEY `idmantenimiento` (`idmantenimiento`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `area`
--
ALTER TABLE `area`
  MODIFY `idarea` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `area_maquina`
--
ALTER TABLE `area_maquina`
  MODIFY `idareamaquina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `cargo`
--
ALTER TABLE `cargo`
  MODIFY `idcargo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de la tabla `documentos`
--
ALTER TABLE `documentos`
  MODIFY `iddocumentos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `empleado`
--
ALTER TABLE `empleado`
  MODIFY `idempleado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de la tabla `eventoscalendar`
--
ALTER TABLE `eventoscalendar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT de la tabla `inicio_sesion`
--
ALTER TABLE `inicio_sesion`
  MODIFY `idinicio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  MODIFY `idmantenimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `maquinas`
--
ALTER TABLE `maquinas`
  MODIFY `idmaquina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `modulos`
--
ALTER TABLE `modulos`
  MODIFY `idmodulos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tipo_matenimiento`
--
ALTER TABLE `tipo_matenimiento`
  MODIFY `idtipo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `area_maquina`
--
ALTER TABLE `area_maquina`
  ADD CONSTRAINT `area_maquina_ibfk_1` FOREIGN KEY (`idmaquina`) REFERENCES `maquinas` (`idmaquina`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `cargo`
--
ALTER TABLE `cargo`
  ADD CONSTRAINT `cargo_ibfk_1` FOREIGN KEY (`idarea`) REFERENCES `area` (`idarea`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD CONSTRAINT `documentos_ibfk_1` FOREIGN KEY (`idmaquina`) REFERENCES `maquinas` (`idmaquina`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD CONSTRAINT `empleado_ibfk_2` FOREIGN KEY (`idcargo`) REFERENCES `cargo` (`idcargo`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `eventoscalendar`
--
ALTER TABLE `eventoscalendar`
  ADD CONSTRAINT `eventoscalendar_ibfk_1` FOREIGN KEY (`idarea`) REFERENCES `area` (`idarea`) ON DELETE CASCADE;

--
-- Filtros para la tabla `inicio_sesion`
--
ALTER TABLE `inicio_sesion`
  ADD CONSTRAINT `inicio_sesion_ibfk_1` FOREIGN KEY (`idempleado`) REFERENCES `empleado` (`idempleado`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  ADD CONSTRAINT `mantenimiento_ibfk_1` FOREIGN KEY (`idempleado`) REFERENCES `empleado` (`idempleado`) ON UPDATE CASCADE,
  ADD CONSTRAINT `mantenimiento_ibfk_3` FOREIGN KEY (`idmaquina`) REFERENCES `maquinas` (`idmaquina`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `permisosempleado`
--
ALTER TABLE `permisosempleado`
  ADD CONSTRAINT `permisosempleado_ibfk_1` FOREIGN KEY (`idmodulos`) REFERENCES `modulos` (`idmodulos`) ON UPDATE CASCADE,
  ADD CONSTRAINT `permisosempleado_ibfk_2` FOREIGN KEY (`idcargo`) REFERENCES `cargo` (`idcargo`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `tipo_matenimiento`
--
ALTER TABLE `tipo_matenimiento`
  ADD CONSTRAINT `tipo_matenimiento_ibfk_1` FOREIGN KEY (`idmantenimiento`) REFERENCES `mantenimiento` (`idmantenimiento`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
