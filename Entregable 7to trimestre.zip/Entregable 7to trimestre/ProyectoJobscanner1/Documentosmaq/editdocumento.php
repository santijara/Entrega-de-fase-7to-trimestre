<body background="../Imagen/Fondo.jpg">
<?php
include("../principales/db.php");
 include("../principales/nabvar.php");

 // El codigo 2-4 me esta conectando con el archivo para la conexion a la base de datos y el nabvar

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM documentos where iddocumentos= $id";
    $result= mysqli_query($conn, $query );
    if (mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $nombre = $row['nombre_documento'];
        $url = $row['url'];
        $idmaquina = $row['idmaquina'];
        // En estas lineas de codigo estoy seleccionando la informacion de la tabla "Documentos" de la base de datos
        // asignandole nombres privados a las caracteristicas que contiene la tabla y lo que se va a modificar
        
        

    }

}

if (isset($_POST['actualizar'])) {
    $id = $_GET['id'];
    $nombre= $_POST['nombredocumento'];
    $idmaquina= $_POST['idmaquina'];
    // por medio del metodo POST el cual se llama del archivo principal para darle funcionalidad al boton y pueda realizar el cambio

     if (file_exists($_FILES['archivo']['tmp_name'])){
      if (move_uploaded_file($_FILES['archivo']['tmp_name'], '../Documentos/'.$_FILES['archivo']['name'])){
                    
                    
        $url = '../Documentos/'.$_FILES['archivo']['name'];
    

    $query = "UPDATE documentos set nombre_documento = '$nombre', url = '$url', idmaquina = '$idmaquina' WHERE iddocumentos=$id";
  mysqli_query($conn, $query);
  $_SESSION['message'] = 'Informacion actualizada correctamente';
  $_SESSION['message_type'] = 'warning';
  header('Location: ../principales/registrardocumentos.php');
   // Se realiza consulta bajo la condicion UPDATE para realizar el proceso en la tabla "cargos" 
    // y darle validez a la actualizacion
      }


    }
    
    


}


    


?>

<?php include('../includes/header.php'); ?>
<!-- Archivo que contiene el footer -->

<div class="container p-4">
  <div class="row">
    <div class="col-md-4 mx-auto">  
    <div class="card card-body">
    <form action="editdocumento.php?id=<?php echo $_GET['id']; ?>" method="POST" enctype="multipart/form-data">
    <div class="form-group">
    <input name="nombredocumento" type="text" class="form-control" value="<?php echo $nombre; ?>"
    class="form-control" placeholder="Actualice la informacion">
    </div>
    <br>

    <div class="form-group">
    <input name="name" type="text" class="form-control" value="<?php echo $url; ?>"
    class="form-control" placeholder="Actualice la informacion">
    <input type="file" name="archivo" >
    </div>

    <div class="form-group">
    <input name="idmaquina" type="text" class="form-control" value="<?php echo $idmaquina; ?>"
    class="form-control" placeholder="Actualice la informacion">
    </div>

        <button class="btn btn-success" name="actualizar">
          Actualizar
<!-- mediante estas lineas de codigo estoy generando una tarjeta con los campos que voy a actualizar -->

          </button>
      </form>
      </div>
    </div>
  </div>
</div>

