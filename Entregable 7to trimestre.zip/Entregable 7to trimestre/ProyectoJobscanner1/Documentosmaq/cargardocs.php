<?php include("../principales/db.php") ?>
<?php include("../includes/header.php") ?>


<?php

if ($_POST['subir']){
     $idmaquina = $_POST["maquina"];
            
            
            if (file_exists($_FILES['archivo']['tmp_name'])){
                
                
                if (move_uploaded_file($_FILES['archivo']['tmp_name'], '../Documentos/'.$_FILES['archivo']['name'])){
                    
                    
                    $url = '../Documentos/'.$_FILES['archivo']['name'];
                    $nombre = $_POST['nombredocumento'];
                    $sql= $conn -> query("INSERT INTO documentos (nombre_documento, url,idmaquina) VALUES ('".$nombre."','".$url."','".$idmaquina."')");
                
                
                }else{
                    echo "no se subio";
                }
            }else{
                
                echo "no se ha subido";

        }

        $_SESSION['message'] = 'Documento guardado';
        $_SESSION['message_type'] = 'success';
      
      header("location: ../principales/registrardocumentos.php");

    }






?>


