

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">

  <li class="nav-item" >
      <a class="btn btn-outline-light" href="index.php">Menu</a> 
      <!-- referencia para el index principal -->
      </li>
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
       
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle"  id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Administración personal
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
          <li><a class="dropdown-item" href="registrarempleados.php">Empleados</a></li>
            <li><a class="dropdown-item" href="registrararea.php">Areas</a></li>
            <li><a class="dropdown-item" href="registrarcargo.php">Cargos</a></li>
            <li><a class="dropdown-item" href="registrarlogin.php">Crear cuentas</a></li>
           
          </ul>
        </li>
        <!-- Estas lineas de codigo contienen la parte visual de los modulos de "administracion personal" -->

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Administración Herramientas
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="registrarmaquinas.php">Maquinas</a></li>
            <li><a class="dropdown-item" href="registrarareamaq.php">Areas</a></li>
            <li><a class="dropdown-item" href="registrardocumentos.php">Documentos</a></li>
            <li><a class="dropdown-item" href="registrartipo.php">Mantenimiento</a></li>
          </ul>
        </li>
        <!-- Estas lineas de codigo contienen la parte visual de los modulos de "administracion herramientas" -->

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle"  id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Modulos generales
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="modulodocumento.php">Documentos</a></li>
            <li><a class="dropdown-item" href="indexcal.php">Calendario</a></li>
            <li><a class="dropdown-item" href="registrarreporte.php">Reportes</a></li>
          </ul>
        </li>
         <!-- Estas lineas de codigo contienen la parte visual de los modulos de "modulos generales" -->

        
        
      </ul>
      
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Que desea buscar..." aria-label="Search" id="buscar" name="buscar">
        <button onclick="buscar_ahora ($('#buscar').value());"class="btn btn-secondary">Buscar</button>
        
      </form>

      <li class="nav-item" >
      <a class="btn btn-primary " href="loguin.php">Cerrar sesion</a>
      </li>
      <!-- Boton para cerrar la sesion del aplicativo -->
      
      
    </div>
  </div>
</nav> 
<!-- por medio de las lineas de codigo dentro de la etiqueta nav estoy generando de manera visual la barra 
de navegacion del aplicativo -->


<script type="text/javascript">

  function buscar_ahora(buscar){
    var parametro = {"buscar":buscar};
    $ajax({
      data:parametros,
      type: 'POST',
      url: 'registrardocumentos.php',
      success: function(data){
        document.getelementById("datos_buscador").innerHTML = data;
      }
    });
  }


</script>
