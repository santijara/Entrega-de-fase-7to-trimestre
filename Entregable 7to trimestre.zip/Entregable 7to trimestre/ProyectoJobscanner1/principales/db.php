<?php

session_start();

$conn = mysqli_connect (
    'localhost',
    'root',
    '',
    'proyecto_jobscanner'
    
    // Por medio de estas lineas de codigo me esta permitiendo conectarme con la base de 
    // datos jobscanner con ayuda del localhost



    


);

if (isset ($conn)){

    echo '';
}



?>