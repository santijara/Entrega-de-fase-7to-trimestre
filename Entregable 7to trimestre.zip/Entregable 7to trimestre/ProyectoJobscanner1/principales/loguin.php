<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="css/style.css"/>  
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/26f23c8366.js" crossorigin="anonymous"></script>
<!-- las lineas de codigo del 4-6 son links para darle funcionalidad al framework de bootstrap -->
</head>
<body background="../Imagen/Fondo.jpg">
  <!-- Contiene la imagen de fondo del modulo -->

<div align="center" class="grid-container">
        <div class="Logo">
            <img width="20%" height="20%" src="../Imagen/LogoTr.png" alt="Logo Jobscanner"> <br> <br>
        </div>



<div class="login">
  <div class="login-triangle"></div>
  
  <h2 class="login-header">Inicio sesion</h2>

  <form action="validaringreso.php" method="POST"  class="login-container">
    <p><input type="text" placeholder="Usuario" name= "usuario"required></p>
    <p><input type="password" placeholder="Contraseña"name= "contraseña"required></p>
    <p><input type="submit" name="ingresar" class="btn btn-primary " value="Ingresar"></p>
  </form> 
</div>
<!-- por medio de estas lineas de codigo mediante el metodo "POST" se realiza la validacion del usuario y la contraseña  -->
<!-- creada en la base de datos para permitir el ingreso al aplicativo -->
<br>
<br>
<br>
<br>
<br>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<!-- Estos script son necesarios para darle funcionalidad a framework de bootstrap y a javascript -->

</body>


</html>

<br>
<br>


<footer class="bg-dark text-center text-white">
  
  <div class="container p-0 pb">
    
    <section class="mb-4">
      <!-- Facebook -->
      <a class="btn btn-outline-light btn-floating m-1" href="https://es-la.facebook.com" role="button"
        ><i class="fab fa-facebook-f"></i
      ></a>

      <!-- Twitter -->
      <a class="btn btn-outline-light btn-floating m-1" href="https://twitter.com/?lang=es" role="button"
        ><i class="fab fa-twitter"></i
      ></a>

      <!-- Google -->
      <a class="btn btn-outline-light btn-floating m-1" href="https://www.google.com/" role="button"
        ><i class="fab fa-google"></i
      ></a>

      <!-- Instagram -->
      <a class="btn btn-outline-light btn-floating m-1" href="https://www.instagram.com/?hl=es" role="button"
        ><i class="fab fa-instagram"></i
      ></a>


    </section>
    
  </div>
  


  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2021 Copyright:
    <a class="text-white" href="">JobScanner.com</a>
  </div>
  
</footer>

