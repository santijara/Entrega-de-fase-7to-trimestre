<?php include("db.php") ?>
<?php include("../includes/header.php") ?>
<?php include("nabvar.php") ?>
<!-- la lineas de codigo del 1-3 me estan conectando con la base de datos, el header y el navbar -->

<br>


      

<h3><span class="badge bg-secondary">Tipo de mantenimiento</span></h3>
<br>


<div class="container p-4">

<div class="row">

<?php 


if (isset($_SESSION['message'])) {?>

<div class="alert alert-<?= $_SESSION['message_type'];?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<!-- Estas lineas de codigo me estan permitiendo darle diseño al mensaje o alerta que mostrará el aplicativo al realizar -->
<!-- alguna modificacion o ingresar un registro nuevo, ademas esta llamando la funcion $_SESSION la cual me permitirá validarlo -->

<?php session_unset();}?>
<div class="card card-body">


<form action ="../tipomantenimiento/guardartipo.php" method = "POST" class="row g-3 needs-validation" novalidate>
  <div class="col-md-4">
    <label  class="form-label">Nombre mantenimiento</label>
    <input type="text" class="form-control" name="nombre" placeholder="Ingrese el nombre del area" required>
    <!-- Por medio del metodo "POST" el cual se ejecutará para conectarlo con el archivo que se muestra "guardarlogin.php"
  el cual contiene el codigo necesario para ejecutar el proceso para guardar un nuevo registro o validar los que ya estan registrados -->
  </div>

  <div class="col-md-4">
   <label class="form-label">Id reporte fallas  <select name="idmantenimiento" class="form-control" >
   
  
    <?php
        
        $queryh = "SELECT idmantenimiento,     CONCAT (idmantenimiento, ' ',descripcion, ', el ID de maquina  es', ' ', idmaquina) AS nombrecompleto FROM mantenimiento order by idmantenimiento";
          $result_cargo = mysqli_query($conn, $queryh);

          ?>
    
    <?php foreach ($result_cargo as $opciones): ?>

    <option value="<?php echo  $opciones['idmantenimiento']  ?>"><?php echo  $opciones['nombrecompleto']  ?> </option>


    <?php endforeach ?>

    </select></label>
     <!-- Se realiza consulta para que en la parte visual del aplicativo y del modulo "tipo de mantenimiento me arroje por orden del "ID" del reporte de las fallas ya que es
   la clave primaria de la tabla "reportes"  conectada con la tabla "tipo de mantenimiento" y es indispensable su visualizacion.-->

  </div>
 
  <br>
  <div class="col-12">
  <input type="submit" name="Guardar" class="btn btn-primary " value="Guardar">
  </div>
  <div class="col-md-8">
    <table class="table table-bordered">
        <thead>
          <tr>
            <th>Nombre mantenimiento</th>
            <th>ID reporte de falla</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $query = "SELECT * FROM tipo_matenimiento order by idtipo desc" ;
          $result_area = mysqli_query($conn, $query);

          while($row = mysqli_fetch_assoc($result_area)){ ?>  
             <tr>
               <td><?php echo $row['nombre_mantenimiento']; ?></td>
               <td><?php echo $row['idmantenimiento']; ?></td>
               <!-- Consulta para que me traiga de manera visual la informacion almacenada en la bases de datos,
               y tener la referencia de lo que esta almacenado, nuevos datos ingresados y la informacion que se eliminay la que se edita -->
               
              
               <td> 
                 <a href="../tipomantenimiento/editetipo.php?id=<?php echo $row['idtipo']?>" class="btn btn-secondary">
                 <i class="fas fa-marker"></i>
                </a>
                <!-- Referencia con el archivo para editar la informacion de los datos registrados -->
                <a href="../tipomantenimiento/deletetipo.php?id=<?php echo $row['idtipo']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
                </a>
                <!-- Referencia con el archivo para eliminar la informacion de los datos registrados -->
                </td>

              </tr>
           <?php }?>

        </tbody>

    </table>


    
 
  </div>
</form>

</div>
</div>
</div>

  
</form>

</div>
</div>

<?php include("../includes/footer.php") ?>
<!-- archivo del footer -->