<?php include("db.php") ?> 
<?php include("../includes/header.php") ?>
<?php include("nabvar.php") ?>

<!-- la lineas de codigo del 1-3 me estan conectando con la base de datos, el header y el navbar -->




<br>

<h3><span class="badge bg-secondary">REGISTRAR AREA</span></h3>
<br>
<div class="container p-4">

<div class="row">

<?php 


if (isset($_SESSION['message'])) {?>

<div class="alert alert-<?= $_SESSION['message_type'];?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

<?php session_unset();}?>
<!-- Estas lineas de codigo me estan permitiendo darle diseño al mensaje o alerta que mostrará el aplicativo al realizar -->
<!-- alguna modificacion o ingresar un registro nuevo -->

<div class="card card-body">

<form action="../area_empleados/guardarregistro.php" method="POST">
  <!-- Por medio del metodo "POST" el cual se ejecutará para conectarlo con el archivo que se muestra
  el cual contiene el codigo necesario para ejecutar el proceso para guardar un nuevo registro -->
  <div class="col-md-4">
    <label class="form-label">Nombre area</label>
    <input type="text" name="nombrearea" class="form-control"  placeholder="Ingrese el nombre del area" required>
   
  </div>
  <br> 

  <div class="col-md-4">
    <label class="form-label">Zona area</label>
    <input type="text" name="zonaarea" class="form-control" placeholder="Ingrese la zona" required>
    <br>  
  
    <input type="submit" name="Guardar" class="btn btn-primary " value="Guardar">
  </div> 
  <!-- Este div contiene la parte visual del modulo para registras las areas donde se encuentra ubicado el empleado -->
  
  <div class="col-md-8">
    <table class="table table-bordered">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Zona</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $query = "SELECT * FROM area order by idarea desc" ; 
          // genero una consulta para que al momento de visualizar la tabla se pueda ver de manera descendente

          $result_area = mysqli_query($conn, $query);

         

          while($row = mysqli_fetch_assoc($result_area)){ ?>  
             <tr>
               <td><?php echo $row['nombre_area']; ?></td>
               <td><?php echo $row['zona_area']; ?></td>
               <td> 
                 <a href="../area_empleados/edit.php?id=<?php echo $row['idarea']?>" class="btn btn-secondary">
                 <i class="fas fa-marker"></i>
                </a>
                <a href="../area_empleados/delete.php?id=<?php echo $row['idarea']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
                </a>
                </td>
                <!-- por medio de la funcion $result_area estoy trayendo de manera visual 
                la tabla de las areas de los empleados -->

              </tr>
           <?php }?> 

        </tbody>

    </table>


    
 
  </div>
</form>

</div>
</div>
</div>

<?php include("../includes/footer.php") ?>  
<!-- contiene el footer del aplicativo -->

