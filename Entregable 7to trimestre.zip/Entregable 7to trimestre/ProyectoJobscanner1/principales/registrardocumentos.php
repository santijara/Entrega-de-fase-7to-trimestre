<?php include("db.php") ?>
<?php include("../includes/header.php") ?>
<?php include("nabvar.php") ?>
<!-- la lineas de codigo del 1-3 me estan conectando con la base de datos, el header y el navbar -->






<br>

<h3><span class="badge bg-secondary">REGISTRAR DOCUMENTOS  <?php //echo $nombremaquina?></span></h3>
<br>
<div class="container p-4">

<div class="row">

<?php 


if (isset($_SESSION['message'])) {?>

<div class="alert alert-<?= $_SESSION['message_type'];?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

<?php session_unset();}?>
  <!-- Estas lineas de codigo me estan permitiendo darle diseño al mensaje o alerta que mostrará el aplicativo al realizar -->
<!-- alguna modificacion o ingresar un registro nuevo -->

<div class="card card-body">

<form  action="../Documentosmaq/cargardocs.php" method="POST" enctype="multipart/form-data"class="row g-3 needs-validation" novalidate>
  <div class="col-md-4">
    <label  class="form-label">Nombre documento</label>
    <input type="text" class="form-control" name="nombredocumento" placeholder="Ingrese el nombre del documento" required>
    <input type="file" name="archivo" >
   <!-- Por medio del metodo "POST" el cual se ejecutará para conectarlo con el archivo que se muestra
  el cual contiene el codigo necesario para ejecutar el proceso para guardar un nuevo registro -->
  </div>

  <div class="col-md-4">
  <label class="form-label">ID maquina  <select name="maquina" class="form-control" >
  
    <?php
        
        $queryb = "SELECT idmaquina,     CONCAT (nombre_maquina, ' ', idmaquina) AS nombrecompleto FROM maquinas order by idmaquina";
          $result_cargo = mysqli_query($conn, $queryb);

          ?>
    
    <?php foreach ($result_cargo as $opciones): ?>

    <option value="<?php echo  $opciones['idmaquina']  ?>"><?php echo  $opciones['nombrecompleto']  ?> </option>
            <!-- Se realiza consulta para que en la parte visual del aplicativo y del modulo me arroje por orden del "ID" de la maquina ya que es
   la clave foranea de otra tabla conectada con la tabla "documentos" y es indispensable su visualizacion.-->


    <?php endforeach ?>

    </select></label>

  </div>
 
  
  <div class="col-12">
  <input type="submit" name="subir" class="btn btn-primary " value="Guardar">
  </div>

  <div class="col-md-8">
    <table class="table table-bordered">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>URL</th>
            <th>ID maquina</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
  
          <?php
          $query = "SELECT * FROM documentos order by iddocumentos desc" ;
          $result_area = mysqli_query($conn, $query);

          while($row = mysqli_fetch_assoc($result_area)){ ?>  
             <tr>
               <td><?php echo $row['nombre_documento']; ?></td>
               <td><?php echo $row['url']; ?></td>
               <td><?php echo $row['idmaquina']; ?></td>
                <!-- Consulta para que me traiga de manera visual la informacion almacenada en la bases de datos,
               y tener la referencia de lo que esta almacenado, nuevos datos ingresados y la informacion que se elimina -->
              
               <td> 
                 <a href="../Documentosmaq/editdocumento.php?id=<?php echo $row['iddocumentos']?>" class="btn btn-secondary">
                 <i class="fas fa-marker"></i>
                </a><!-- Referencia con el archivo para editar la informacion de los documentos -->
                <a href="../Documentosmaq/deletedocumento.php?id=<?php echo $row['iddocumentos']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
                </a><!-- Referencia con el archivo para eliminar la informacion de los documentos -->
                </td>

              </tr>
           <?php }?>

        </tbody>

    </table>


    
 
  </div>
</form>

</div>

</div>
</div>

<?php include("../includes/footer.php") ?>
<!-- conexion con el footer -->