<?php

include("db.php");

if($_POST['ingresar']){
  $usuario = $_POST["usuario"];
  $contraseña = $_POST["contraseña"];
 
  $_SESSION["usuario"]=$usuario;


  $query = "SELECT * FROM  inicio_sesion where usuario = '$usuario' and contraseña= '$contraseña'";
  $result= mysqli_query($conn, $query);

  $filas=mysqli_num_rows($result);

  

  if($filas){

    header("location: index.php");

  }else{

    

    ?> 
    <h1 class="bg-danger"> Error en la autenticacion </h1>
    <?php
    
    include("loguin.php");
    ?> 
    


    <?php
  }
}

  mysqli_free_result($result);
  mysqli_close($conn);
