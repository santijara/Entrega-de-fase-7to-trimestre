<?php include("db.php") ?>
<?php include("../includes/header.php") ?>
<?php include("nabvar.php") ?>
<!-- la lineas de codigo del 1-3 me estan conectando con la base de datos, el header y el navbar -->


<br>

<h3><span class="badge bg-secondary">Reportes Empleado</span></h3>
<br>
<div class="container p-4">

<div class="row">

<?php 


if (isset($_SESSION['message'])) {?>

<div class="alert alert-<?= $_SESSION['message_type'];?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<!-- Estas lineas de codigo me estan permitiendo darle diseño al mensaje o alerta que mostrará el aplicativo al realizar -->
<!-- alguna modificacion o ingresar un registro nuevo, ademas esta llamando la funcion $_SESSION la cual me permitirá validarlo -->
<?php session_unset();}?>

<div class="card card-body">

<form action="../reportes/guardarreporte.php" method="POST" class="row g-3 needs-validation" novalidate>
  <div class="col-md-4">
  <label class="form-label">Fecha reporte</label>
  <input type="text" name="fecha" class="form-control"  placeholder="Ingrese la fecha del reporte" required>
   <!-- Por medio del metodo "POST" el cual se ejecutará para conectarlo con el archivo que se muestra "guardarlogin.php"
  el cual contiene el codigo necesario para ejecutar el proceso para guardar un nuevo registro o validar los que ya estan registrados -->
  </div>
  <div class="col-md-4">
    <label class="form-label">Descripcion reporte</label>
    <input type="text" name="descripcion" class="form-control"  placeholder="Ingrese la descripcion del reporte" required>
    
  </div>
  
  <div class="col-md-4">
    <label class="form-label">ID empleado <select name="idempleado" class="form-control">
    <?php
        
        $queryc = "SELECT idempleado,     CONCAT (idempleado,' ',nombre_empleado, ' ', apellido) AS nombrecompleto FROM empleado order by idempleado";
          $result_m = mysqli_query($conn, $queryc);

          ?>
    
    <?php foreach ($result_m as $opciones): ?>

    <option value="<?php echo  $opciones['idempleado']  ?>"><?php echo  $opciones['nombrecompleto']  ?> </option>


    <?php endforeach ?>

    </select></label>
    <!-- Se realiza consulta para que en la parte visual del aplicativo y del modulo me arroje por orden del "ID" del empleado ya que es
   la clave primaria de la tabla "empledos" conectada con la tabla "reportes" y es indispensable su visualizacion.-->

  </div>

    
  </div>
  <div class="col-md-4">
    <label class="form-label">ID maquina <select name="idmaquina" class="form-control">
    <?php
        
        $queryd = "SELECT idmaquina,     CONCAT (nombre_maquina, ' ', idmaquina) AS nombrecompleto FROM maquinas order by idmaquina";
          $result_cargo = mysqli_query($conn, $queryd);

          ?>
    
    <?php foreach ($result_cargo as $opciones): ?>

    <option value="<?php echo  $opciones['idmaquina']  ?>"><?php echo  $opciones['nombrecompleto']  ?> </option>


    <?php endforeach ?>

    </select></label>

  </div>



 

  </div>


  

  <div class="col-12">

  <input type="submit" name="Reportar" class="btn btn-primary " value="Reportar">
  </div>

  <div class="col-md-15">
    <table class="table table-bordered">
        <thead>
          <tr>
            <th>Fecha</th>
            <th>Descripcion</th>
            <th>ID empleado</th>
            <th>ID maquina</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $query = "SELECT * FROM mantenimiento order by idmantenimiento desc" ;
          $result_area = mysqli_query($conn, $query);

          while($row = mysqli_fetch_assoc($result_area)){ ?>  
             <tr>
               <td><?php echo $row['fecha']; ?></td>
               <td><?php echo $row['descripcion']; ?></td>
               <td><?php echo $row['idempleado']; ?></td>
               <td><?php echo $row['idmaquina']; ?></td>
               <!-- Consulta para que me traiga de manera visual la informacion almacenada en la bases de datos,
               y tener la referencia de lo que esta almacenado, nuevos datos ingresados y la informacion que se elimina -->
            
               <td> 
                 <a href="../reportes/editereporte.php?id=<?php echo $row['idmantenimiento']?>" class="btn btn-secondary">
                 <i class="fas fa-marker"></i>
                </a>
                 <!-- Referencia con el archivo para editar la informacion de los datos registrados -->

                <a href="../reportes/deletereporte.php?id=<?php echo $row['idmantenimiento']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
                </a>
                </td>
                <!-- Referencia con el archivo para eliminar la informacion de los datos registrados -->

              </tr>
           <?php }?>

        </tbody>

    </table>


    
 
  </div>
</form>

</div>
</div>

</div>

<?php include("../includes/footer.php") ?>
<!-- archivo del footer -->