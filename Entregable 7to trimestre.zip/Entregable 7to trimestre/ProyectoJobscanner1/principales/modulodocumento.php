<?php include("db.php") ?>  <!-- Este archivo contiene la conexion con la base de datos -->
<?php include("../includes/header.php") ?> <!-- Este archivo contiene el header del aplicativo -->
<?php include("nabvar.php") ?> <!-- Este archivo contiene el navbar del aplicativo (barra de navegacion)-->

<!DOCTYPE html>
<html lang="en">
	

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Filtrando elementos por categorias</title>

    <link rel="stylesheet" href="../modulodocumentos/css/estilos.css">
    <!-- <link rel="stylesheet" href="modulodocumentos/style.css"> -->

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">

    <script src="../modulodocumentos/js/jquery-3.2.1.js"></script>
    <script src="../modulodocumentos/js/script.js"></script>
</head >

<div align="center" class="grid-container">
    <div class="Logo">
        <img width="20%" height="20%" src="../Imagen/LogoTr.png" alt="Logo Jobscanner"> <br> <br>
    </div> 
    <!-- Contiene el logo del proyecto -->

</div>



<body>
	
    <div align="center" class="grid-container">
    <a class="btn btn-outline-secondary" href="index.php" role="button" >Volver al menu principal</a>
    </div>

    <div class="wrap">
        <h1>Escoge la seccion </h1>
        <div class="store-wrapper">
            <div class="category_list">
                <a href="#" class="category_item" category="all">Todo Los Documentos</a>
                <a href="#" class="category_item" category="Seleccion 1">Seccion 1</a>
                <a href="#" class="category_item" category="Seleccion 2">Seccion 2</a>
                <a href="#" class="category_item" category="Seleccion 3">Seccion 3</a>
                <a href="#" class="category_item" category="Seleccion 4">Seccion 4</a>
                <a href="#" class="category_item" category="Seleccion 5">Seccion 5</a>
            </div>
            <!-- Me permite buscar por secciones los documentos pertenecientes a cada una de ellas -->
            <section class="products-list">
                <div class="product-item" category="Seleccion 2">
                    <img src="../modulodocumentos/images/mantenimiento.png" alt="">
                    <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">Estandares De Seguridad Esmeril</a>
                    <a href="../Documentos/ESTANDARES DE SEGURIDAD ESMERIL.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 2">
                    <img src="../modulodocumentos/images/vibara.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">Vibradoras</a>
                    <a href="../Documentos/Vibradora.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 2">
                    <img src="../modulodocumentos/images/Centri.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">Centrifugadora</a>
                    <a href="../Documentos/Centrifugadora.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 3">
                    <img src="../modulodocumentos/images/recti.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">ESTANDARES DE SEGURIDAD RECTIFICADORA</a>
                    <a href="../Documentos/ESTANDARES DE SEGURIDAD RECTIFICADORA.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 3">
                    <img src="../modulodocumentos/images/troque.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">ESTANDARES DE SEGURIDAD TROQUELADORA</a>
                    <a href="../Documentos/ESTANDARES DE SEGURIDAD TROQUELADORA.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 3">
                    <img src="../modulodocumentos/images/PULI.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">PULIDORA</a>
                    <a href="../Documentos/pulidora.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 3">
                    <img src="../modulodocumentos/images/TRONZA.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">TRONZADORA </a>
                    <a href="../Documentos/tronza.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 1">
                    <img src="../modulodocumentos/images/taladrodebanco.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">Taladro de banco</a>
                    <a href="../Documentos/ESTANDARES DE SEGURIDAD TALADRO DE BANCO.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->

                </div>
                <div class="product-item" category="Seleccion 1">
                    <img src="../modulodocumentos/images/fresadora.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">Fresadora</a>
                    <a href="../Documentos/Fresadora.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 1">
                    <img src="../modulodocumentos/images/inyectoras.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">Inyectoras</a>
                    <a href="../Documentos/INYECTORAS.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 1">
                    <img src="../modulodocumentos/images/sierrasinfin.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">Sierra sin fin</a>
                    <a href="../Documentos/SIERRASINFIN.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 1">
                    <img src="../modulodocumentos/images/torno.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">Estandares De Seguriad Torno Convencional</a>
                    <a href="../Documentos/ESTANDARES DE SEGURIDAD TORNO.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 1">
                    <img src="../modulodocumentos/images/puntilladora.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">Puntilladora Troqueladora</a>
                    <a href="../Documentos/puntilladora.pdf" download>Descargar</a>
                </div>
                <div class="product-item" category="Seleccion 1">
                    <img src="../modulodocumentos/images/sizalla.jpg" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">Cizalla</a>
                    <a href="../Documentos/sicalla.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 4">
                    <img src="../modulodocumentos/images/MORTA.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">MORTAJADORA</a>
                    <a href="../Documentos/mortaja.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 4">
                    <img src="../modulodocumentos/images/MANDRI.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">MANDRILADORA</a>
                    <a href="../Documentos/MANDRI.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 5">
                    <img src="../modulodocumentos/images/PREN.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">PRENSA HIDRAULICA</a>
                    <a href="../Documentos/PRENSA.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 5">
                    <img src="../modulodocumentos/images/taller.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">ESTANDARES DE SEGURIDAD TALLER</a>
                    <a href="../Documentos/ESTANDARES DE SEGURIDAD TALLER.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
                <div class="product-item" category="Seleccion 5">
                    <img src="../modulodocumentos/images/gestan.png" alt="">
                     <!-- La ruta de la imagen que se mostrará -->
                    <a href="#">ESTANDARES DE SEGURIDAD MONTAJE DE TROQUELES</a>
                    <a href="../Documentos/ESTANDARES DE SEGURIDAD MONTAJE DE TROQUELES.pdf" download>Descargar</a>
                    <!-- La ruta del documento que se podrá descargar y visualizar -->
                </div>
            </section> 
            <!-- la section me contiene toda la parte visual del modulo de documentos con cada una de las maquinas 
            registradas con sus respectivos documentos. -->
        </div>
    </div>
    
</body>

</html>

<?php include("../includes/footer.php") ?> 
<!-- este include contiene el footer del aplicativo -->