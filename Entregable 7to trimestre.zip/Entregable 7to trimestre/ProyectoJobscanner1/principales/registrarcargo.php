<?php include("db.php") ?>
<?php include("../includes/header.php") ?>
<?php include("nabvar.php") ?>
<!-- la lineas de codigo del 1-3 me estan conectando con la base de datos, el header y el navbar -->

<br>

<h3><span class="badge bg-secondary">REGISTRAR CARGO</span></h3>
<br>
<div class="container p-4">

<div class="row">

<?php 


if (isset($_SESSION['message'])) {?>

<div class="alert alert-<?= $_SESSION['message_type'];?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

<?php session_unset();}?>
  <!-- Estas lineas de codigo me estan permitiendo darle diseño al mensaje o alerta que mostrará el aplicativo al realizar -->
<!-- alguna modificacion o ingresar un registro nuevo -->

<div class="card card-body">

<form action="../cargo_empleados/guardarcargo.php" method="POST">
  <div class="col-md-4">
    <label class="form-label">Nombre cargo</label>
    <input type="text" name="nombrecargo" class="form-control"  placeholder="Ingrese el nombre del cargo" required>
 <!-- Por medio del metodo "POST" el cual se ejecutará para conectarlo con el archivo que se muestra
  el cual contiene el codigo necesario para ejecutar el proceso para guardar un nuevo registro -->
    
    <br>

<label class="form-label">Id area  <select name="idarea" class="form-control">
  
    <?php
        
        $queryj = "SELECT idarea,     CONCAT (nombre_area, ' ', idarea) AS nombrecompleto FROM area order by idarea";
          $result_area = mysqli_query($conn, $queryj);

          ?>
    
    <?php foreach ($result_area as $opciones): ?>

    <option value="<?php echo  $opciones['idarea']  ?>"><?php echo  $opciones['nombrecompleto']  ?> </option>


    <?php endforeach ?>
        <!-- Se realiza consulta para que en la parte visual del aplicativo me arroje por orden del "ID" del area ya que es
   la clave foranea de otra tabla conectada con la tabla "cargo" y es indispensable su visualizacion.-->

    </select></label>
    <br>
    <br>  
  
    <input type="submit" name="Guardar" class="btn btn-primary " value="Guardar">
  
  </div>

  <br>

 

  <div class="col-md-8">
    <table class="table table-bordered">
        <thead>
          <tr>
            <th>Nombre cargo</th>
            <th>ID area</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php
        
          $query = "SELECT E.*, C.nombre_area FROM cargo E INNER JOIN area C ON E.idarea=C.idarea";
          $result_cargo = mysqli_query($conn, $query);

          while($row = mysqli_fetch_assoc($result_cargo)){ ?>  
             <tr>
               <td><?php echo $row['nombre_cargo']; ?></td>
               <td><?php echo $row['nombre_area']; ?></td>
               <!-- Consulta para que me traiga de manera visual la informacion almacenada en la bases de datos,
               y tener la referencia de lo que esta almacenado, nuevos datos ingresados y la informacion que se elimina -->
            
               <td> 
                 <a href="../cargo_empleados/editcargo.php?id=<?php echo $row['idcargo']?>" class="btn btn-secondary">
                 <i class="fas fa-marker"></i>
                </a>
                 <!-- Referencia con el archivo para editar la informacion del cargo -->
                <a href="../cargo_empleados/deletecargo.php?id=<?php echo $row['idcargo']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
                </a>
                 <!-- Referencia con el archivo para eliminar la informacion de los registros del cargo -->
                </td>

              </tr>
           <?php }?>

        </tbody>

    </table>

  

  </div>
</form>
</div>

</div>


</div>

<?php include("../includes/footer.php") ?>