<?php include("db.php") ?>
<?php include("../includes/header.php") ?>
<?php include("nabvar.php") ?>
<!-- la lineas de codigo del 1-3 me estan conectando con la base de datos, el header y el navbar -->

<br>



<h3><span class="badge bg-secondary">Inicio sesion</span></h3>
<br>
<div class="container p-4">

<div class="row">

<?php 


if (isset($_SESSION['message'])) {?>

<div class="alert alert-<?= $_SESSION['message_type'];?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

<?php session_unset();}?>
 <!-- Estas lineas de codigo me estan permitiendo darle diseño al mensaje o alerta que mostrará el aplicativo al realizar -->
<!-- alguna modificacion o ingresar un registro nuevo, ademas esta llamando la funcion $_SESSION la cual me permitirá validarlo -->

<div class="card card-body">

<form action="../iniciosesion/guardarlogin.php" method="POST" class="row g-3 needs-validation" novalidate >
  <div class="col-md-4">
    <label class="form-label">Usuario</label>
    <input type="text" name="usuario" class="form-control"  placeholder="Ingrese el usuario" required>
   
  </div>
  <!-- Por medio del metodo "POST" el cual se ejecutará para conectarlo con el archivo que se muestra "guardarlogin.php"
  el cual contiene el codigo necesario para ejecutar el proceso para guardar un nuevo registro o validar los que ya estan registrados -->
  <br> 

  <div class="col-md-4">
    <label class="form-label">Contraseña</label>
    <input type="text" name="contraseña" class="form-control" placeholder="Ingrese la contraseña" required>
    
  
    </div>
    <br>  

    <div class="col-md-4">
   <label class="form-label">Id empleado  <select name="idempleado" class="form-control" >
   
  
    <?php
        
          $queryb = "SELECT idempleado,     CONCAT (idempleado,' ',nombre_empleado, ' ', apellido) AS nombrecompleto FROM empleado order by idempleado";
          $result_ini = mysqli_query($conn, $queryb);

          ?>
    
    <?php foreach ($result_ini as $opciones): ?>
        

    <option value="<?php echo  $opciones['idempleado']  ?>"><?php echo  $opciones['nombrecompleto']  ?> </option>


    <?php endforeach ?>

    </select></label>
    <!-- Se realiza consulta para que en la parte visual del aplicativo y del modulo me arroje por orden del "ID" del empleado ya que es
   la clave foranea de la tabla "inicio_sesion" conectada con la tabla "empleados" y es indispensable su visualizacion.-->

  </div>

  <div class="col-12">

  <input type="submit" name="Guardar" class="btn btn-primary " value="Guardar">
  </div>
  

    
  
  
  <div class="col-md-10">
    <table class="table table-bordered">
        <thead>
          <tr>
            <th>Usuario</th>
            <th>Contraseña</th>
            <th>ID empleado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
           <!-- Consulta para que me traiga de manera visual la informacion almacenada en la bases de datos,
               y tener la referencia de lo que esta almacenado, nuevos datos ingresados y la informacion que se elimina -->
          <?php
          $query = "SELECT E.*, C.nombre_empleado, C.apellido FROM inicio_sesion E INNER JOIN empleado C ON E.idempleado=C.idempleado"  ;
          $result_area = mysqli_query($conn, $query);

          while($row = mysqli_fetch_assoc($result_area)){ ?>  
             <tr>
               <td><?php echo $row['usuario']; ?></td>
               <td><?php echo $row['contraseña']; ?></td>
               <td><?php echo $row['idempleado']; ?></td>
               <td> 
                 <a href="../iniciosesion/editlogin.php?id=<?php echo $row['idinicio']?>" class="btn btn-secondary">
                 <i class="fas fa-marker"></i>
                </a>
                <!-- Referencia con el archivo para editar la informacion de los datos registrados -->
                <a href="../iniciosesion/deletelogin.php?id=<?php echo $row['idinicio']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
                </a>
                </td>
                <!-- Referencia con el archivo para eliminar la informacion de los datos registrados -->

              </tr>
           <?php }?>

        </tbody>

    </table>


    
 
  </div>
</form>

</div>
</div>
</div>

<?php include("../includes/footer.php") ?>
<!-- archivo del footer -->
