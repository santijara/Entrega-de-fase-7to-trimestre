 <?php include("db.php") ?> <!--incluye el archivo para la conexion a la base de datos -->
<?php include("../includes/header.php") ?> <!--incluye el archivo del header del proyecto -->
<?php include("nabvar.php") ?> <!--incluye el archivo del navbar (navegacion del proyecto)-->




<br>

<div align="center" class="grid-container">
        <div class="Logo">
            <img width="20%" height="20%" src="../Imagen/LogoTr.png" alt="Logo Jobscanner"> <br> <br>
        </div> 
        <!-- Este div contiene la clase para centrar la informacion, ademas contiene el "src" 
        del logo del proyecto -->

<div class="container">
  
  <h2> Proyecto dedicado a brindar una informacion correcta y precisa de las maquinas pertenencientes a una organizacion.</h2>
  
  <br>

  <div class="row">
  
    <div class="col-md-4">
    <h2 class="text-muted">Proceso para el reporte adecuado de los inconvenientes con la maquinaria</h2>
      <div class="thumbnail">
        <a  href="registrarreporte.php" target="_blank">
          <img src="../imagen/maquinaria1.jpg" alt="Nature" style="width:100%">
          <div class="caption">
              <br>
          <button type="button" class="btn btn-secondary">Reporte fallas</button>
      
          </div>  <!-- Este div contiene la informacion sobre el acceso rapido al modulo de
                       reportes de fallas contiene una imagen y texto -->
        </a>
      </div>
    </div>
    
    <div class="col-md-4">
    <h2 class="text-muted">Tener la informacion al alcance de tus manos para validar el correcto uso y operaciones de las maquinas</h2>
      <div class="thumbnail">
        <a href= "modulodocumento.php"target="_blank">
          <img src="../imagen/trabajador.jpg" alt="Nature" style="width:100%">
          <div class="caption">
          <br>
          <button type="button" class="btn btn-secondary">Documentos</button>
          </div> <!-- Este div contiene la informacion sobre el acceso rapido al modulo de
                       reportes de fallas contiene una imagen y texto -->
        </a>
      </div>
    </div>
    <div class="col-md-4">
    <h2 class="text-muted">Valida el cronograma que se tiene para este año 2022</h2>
      <div class="thumbnail">
        <a href="indexcal.php" target="_blank">
          <img src="../imagen/calendario.png" alt="nature" style="width:100%">
          <div class="caption">
          <br>
          <button type="button" class="btn btn-secondary">Calendario programacion</button>
          </div> <!-- Este div contiene la informacion sobre el acceso rapido al modulo de
                       reportes de fallas contiene una imagen y texto -->
        </a>
      </div>
    </div>
  </div>
</div>

</body>
</html>




<?php include("../includes/footer.php") ?> <!-- Esta include contiene el footer del aplicativo -->

