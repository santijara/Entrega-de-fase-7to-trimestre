<?php include("db.php") ?>
<?php include("../includes/header.php") ?>
<?php include("nabvar.php") ?>
<!-- la lineas de codigo del 1-3 me estan conectando con la base de datos, el header y el navbar -->

<br>

<h3><span class="badge bg-secondary">REGISTRAR EMPLEADOS</span></h3>
<br>
<div class="container p-4">

<div class="row">

<?php 


if (isset($_SESSION['message'])) {?>

<div class="alert alert-<?= $_SESSION['message_type'];?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
 <!-- Estas lineas de codigo me estan permitiendo darle diseño al mensaje o alerta que mostrará el aplicativo al realizar -->
<!-- alguna modificacion o ingresar un registro nuevo -->

<?php session_unset();}?>

<div class="card card-body">

<form action="../Empleados/guardarempleado.php" method="POST" class="row g-3 needs-validation" novalidate>
  <div class="col-md-4">
  <label class="form-label">Nombre empleado</label>
  <input type="text" name="nombre" class="form-control"  placeholder="Ingrese el nombre del empleado" required>
   <!-- Por medio del metodo "POST" el cual se ejecutará para conectarlo con el archivo que se muestra
  el cual contiene el codigo necesario para ejecutar el proceso para guardar un nuevo registro -->
  </div>
  <div class="col-md-4">
    <label class="form-label">Apellido</label>
    <input type="text" name="apellido" class="form-control"  placeholder="Ingrese el apellido del empleado" required>
    
  </div>
  
  <div class="col-md-4">
    <label class="form-label">Direccion</label>
    <input type="text" name="direccion" class="form-control"  placeholder="Ingrese la direccion" required>
    
  </div>
  <div class="col-md-4">
    <label class="form-label">Salario</label>
    <input type="text" name="salario" class="form-control"  placeholder="Ingrese el salario empleado" required>
    

  </div>

  <div class="col-md-4">
    <label class="form-label">Genero</label>
    <input type="text" name="genero" class="form-control"  placeholder="Ingrese el genero del empleado" required>
  
  </div>

  <div class="col-md-4">
    <label class="form-label">Correo Electronico</label>
    <div class="input-group has-validation">
      <span class="input-group-text" id="inputGroupPrepend">@</span>
      <input type="text" name="correo" class="form-control"  placeholder="Ingrese el correo electronico" required>
    
    </div>
  </div>
  
  <div class="col-md-4">
    <label class="form-label">Fecha de nacimiento</label>
    <input type="text" name="fecha" class="form-control"  placeholder="Ingrese la fecha de nacimiento" required>
    </div>
  

  
    <div class="col-md-4">
   <label class="form-label">Id cargo  <select name="idcargo" class="form-control" >
   
  
    <?php
        
        $queryh = "SELECT idcargo,     CONCAT (nombre_cargo, ' ', idcargo) AS nombrecompleto FROM cargo order by idcargo";
          $result_cargo = mysqli_query($conn, $queryh);

          ?>
    
    <?php foreach ($result_cargo as $opciones): ?>

    <option value="<?php echo  $opciones['idcargo']  ?>"><?php echo  $opciones['nombrecompleto']  ?> </option>


    <?php endforeach ?>

    </select></label>

  </div>
  <!-- Se realiza consulta para que en la parte visual del aplicativo y del modulo me arroje por orden del "ID" del cargo ya que es
   la clave foranea de la tabla "cargos" conectada con la tabla "empleados" y es indispensable su visualizacion.-->


  

  <div class="col-12">

  <input type="submit" name="Guardar" class="btn btn-primary " value="Guardar">
  </div>

  <div class="col-md-15">
    <table class="table table-bordered">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Genero</th>
            <th>Direccion</th>
            <th>Salario</th>
            <th>Correo electronico</th>
            <th>Fecha de nacimiento</th>
            <th>ID cargo</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $query = "SELECT E.*, C.nombre_cargo FROM empleado E INNER JOIN cargo C ON E.idcargo=C.idcargo" ;
          $result_area = mysqli_query($conn, $query);

          while($row = mysqli_fetch_assoc($result_area)){ ?>  
             <tr>
               <td><?php echo $row['nombre_empleado']; ?></td>
               <td><?php echo $row['apellido']; ?></td>
               <td><?php echo $row['genero']; ?></td>
               <td><?php echo $row['direccion']; ?></td>
               <td><?php echo $row['salario']; ?></td>
               <td><?php echo $row['email']; ?></td>
               <td><?php echo $row['fecha_nacimiento']; ?></td>
               <td><?php echo $row['nombre_cargo']; ?></td>
               <td> 
                 <!-- Consulta para que me traiga de manera visual la informacion almacenada en la bases de datos,
               y tener la referencia de lo que esta almacenado, nuevos datos ingresados y la informacion que se elimina -->

                 <a href="../Empleados/editeempleado.php?id=<?php echo $row['idempleado']?>" class="btn btn-secondary">
                 <i class="fas fa-marker"></i>
                </a>
                <!-- Referencia con el archivo para editar la informacion de los empleados -->
              
                <a href="../Empleados/deleteempleado.php?id=<?php echo $row['idempleado']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
                </a>
                <!-- Referencia con el archivo para eliminar la informacion de los empleados -->
                </td>

              </tr>
           <?php }?>

        </tbody>

    </table>


    
 
  </div>
</form>

</div>
</div>

</div>

<?php include("../includes/footer.php") ?> 
<!-- archivo del footer -->