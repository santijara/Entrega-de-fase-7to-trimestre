<body background="../Imagen/Fondo.jpg">
<?php
include("../principales/db.php");
include("../principales/nabvar.php");

// El codigo 2-4 me esta conectando con el archivo para la conexion a la base de datos y el nabvar

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM tipo_matenimiento where idtipo= $id";
    $result= mysqli_query($conn, $query );
    if (mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $nombretipo= $row['nombre_mantenimiento'];
        $nombreid= $row['idmantenimiento'];
       
        
 // En estas lineas de codigo estoy seleccionando la informacion de la tabla "tipo_mantenimiento" de la base de datos
        // asignandole nombres privados a las caracteristicas que contiene la tabla y lo que se va a modificar
    }

}

if (isset($_POST['actualizar'])) {
    $id = $_GET['id'];
    $nombretipo= $_POST['nombre'];
    $nombreid= $_POST['idmantenimiento'];

    $query = "UPDATE tipo_matenimiento set nombre_mantenimiento = '$nombretipo', idmantenimiento = '$nombreid' WHERE idtipo=$id";
  mysqli_query($conn, $query);
  $_SESSION['message'] = 'Informacion actualizada correctamente';
  $_SESSION['message_type'] = 'warning';
  header('Location: ../principales/registrartipo.php');

    
     // Se realiza consulta bajo la condicion UPDATE para realizar el proceso en la tabla "tipo_mantenimiento" 
    // y darle validez a la actualizacion


}


    


?>

<?php include('../includes/header.php'); ?>
<!-- Archivo que contiene el footer -->

<div class="container p-4">
  <div class="row">
    <div class="col-md-4 mx-auto">  
    <div class="card card-body">
    <form action="editetipo.php?id=<?php echo $_GET['id']; ?>" method="POST">
    <div class="form-group">
    <input name="nombre" type="text" class="form-control" value="<?php echo $nombretipo; ?>"
    class="form-control" placeholder="Actualice la informacion">
    </div>
    <br>
    <div class="form-group">
    <input name="idmantenimiento" type="text" class="form-control" value="<?php echo $nombreid; ?>"
    class="form-control" placeholder="Actualice la informacion">
    </div>
    <br>



    
        <button class="btn btn-success" name="actualizar">
          Actualizar

          <!-- mediante estas lineas de codigo estoy generando una tarjeta con los campos que voy a actualizar -->

          </button>
      </form>
      </div>
    </div>
  </div>
</div>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
