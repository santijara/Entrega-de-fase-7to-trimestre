<?php

include("../principales/db.php");
// codigo que contiene la conexion con el archivo de la base de datos


if (isset($_POST['Guardar'])) {
  $nombretipo = $_POST["nombre"];
  $nombreid= $_POST["idmantenimiento"];
  
// Mediante la funcion $_POST para ejecutar la opcion de guardar de los campos que contiene el modulo,
// conectado con el archivo principal "registrartipo.php"

  $query = "INSERT INTO tipo_matenimiento (nombre_mantenimiento, idmantenimiento) VALUES ('$nombretipo', '$nombreid')";
  $result= mysqli_query($conn, $query);

  // Se realiza consulta bajo la funcion INSERT INTO para ingresar los datos en los campos
  // que se necesitan para la tabla "tipo_mantenimiento"


  if (!$result) {
   die('falló');
  }

  $_SESSION['message'] = 'Tipo de mantenimiento guardado';
  $_SESSION['message_type'] = 'success';

header("location: ../principales/registrartipo.php");
// redireccion al archivo principal del modulo "tipo_mantenimiento"

}

?>