<?php

include("../principales/db.php");
// Se incluye archivo de la base de datos

if(isset($_GET['id'])) {
  $id = $_GET['id'];
  $query = "DELETE FROM tipo_matenimiento WHERE idtipo = $id";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }
  // } consulta y proceso para ejecutar la funcion "DELETE" en la tabla "tipo_mantenimiento" para eliminar los registros seleccionados

  $_SESSION['message'] = 'Eliminado correctamente';
  $_SESSION['message_type'] = 'danger';
  header("Location: ../principales/registrartipo.php");
      // me lleva al modulo principal de "mantenimiento"
}

?>
