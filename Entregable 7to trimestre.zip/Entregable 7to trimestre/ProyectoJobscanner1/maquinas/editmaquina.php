<body background="../Imagen/Fondo.jpg">
<?php
include("../principales/db.php");
include("../principales/nabvar.php");
// El codigo 2-4 me esta conectando con el archivo para la conexion a la base de datos y el nabvar

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM maquinas where idmaquina = $id";
    $result= mysqli_query($conn, $query );
    if (mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $nombre = $row['nombre_maquina'];
        $marca = $row['marca'];
        $peso = $row['peso'];
        $color = $row['color'];
        // En estas lineas de codigo estoy seleccionando la informacion de la tabla "maquinas" de la base de datos
        // asignandole nombres privados a las caracteristicas que contiene la tabla y lo que se va a modificar

    }

}

if (isset($_POST['actualizar'])) {
    $id = $_GET['id'];
    $nombre= $_POST['nombre'];
    $marca = $_POST['marca'];
    $peso = $_POST['peso'];
    $color = $_POST['color'];


    $query = "UPDATE maquinas set nombre_maquina = '$nombre', marca = '$marca', peso ='$peso',  color ='$color' WHERE idmaquina=$id";
  mysqli_query($conn, $query);
  $_SESSION['message'] = 'Informacion actualizada correctamente';
  $_SESSION['message_type'] = 'warning';
  header('Location: ../principales/registrarmaquinas.php');

  // Se realiza consulta bajo la condicion UPDATE para realizar el proceso en la tabla "maquinas" 
    // y darle validez a la actualizacion

    
    


}


    


?>

<?php include('../includes/header.php'); ?>

<div class="container p-4">
  <div class="row">
    <div class="col-md-4 mx-auto">  
    <div class="card card-body">
    <form action="editmaquina.php?id=<?php echo $_GET['id']; ?>" method="POST" >
    <div class="form-group">
    <label class="form-label">Nombre</label>
    <input name="nombre" type="text" class="form-control" value="<?php echo $nombre; ?>"
    class="form-control" placeholder="Actualice la informacion">
    </div>
    <div class="form-group">
    <div class="card card-body">
    <label class="form-label">Marca</label>
        <textarea name="marca" class="form-control"><?php echo $marca;?></textarea>
        </div>
        <div class="form-group">
        <div class="card card-body">
        <label class="form-label">Peso</label>
        <textarea name="peso" class="form-control" ><?php echo $peso;?></textarea>
        </div>
        <div class="form-group">
        <div class="card card-body">
        <label class="form-label">Color</label>
        <textarea name="color" class="form-control" ><?php echo $color;?></textarea>
        </div>
        <button class="btn btn-success" name="actualizar">
          Actualizar

          </button>
      </form>
      </div>
    </div>
  </div>
</div>

