<?php

include("../principales/db.php");

if (isset($_POST['Guardar'])) {
  $nombremaquina = $_POST["nombre"];
  $marca = $_POST["marca"];
  $peso = $_POST["peso"];
  $color = $_POST["color"];
// Mediante la funcion $_POST para ejecutar la opcion de guardar de los campos que contiene el modulo,
// conectado con el archivo principal "registrarmaquinas.php"

  $query = "INSERT INTO maquinas (nombre_maquina, marca, peso, color) VALUES ('$nombremaquina', '$marca','$peso','$color')";
  $result= mysqli_query($conn, $query);

  
 // Se realiza consulta bajo la funcion INSERT INTO para ingresar los datos en los campos
  // que se necesitan para la tabla "maquinas"
  

  if (!$result) {
   die('falló');
  }

  $_SESSION['message'] = 'Maquina guardada';
  $_SESSION['message_type'] = 'success';

header("location: ../principales/registrarmaquinas.php");

}

?>