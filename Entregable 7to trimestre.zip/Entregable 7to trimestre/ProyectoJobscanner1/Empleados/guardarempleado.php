<?php

include("../principales/db.php");
// codigo que contiene la conexion con el archivo de la base de datos

if (isset($_POST['Guardar'])) {
  $nombreempleado = $_POST["nombre"];
  $apellidoempleado = $_POST["apellido"];
  $genero = $_POST["genero"];
  $direccion = $_POST["direccion"];
  $salario = $_POST["salario"];
  $correo = $_POST["correo"];
  $fecha = $_POST["fecha"];
  $idcargo = $_POST["idcargo"];

  // Mediante la funcion $_POST para ejecutar la opcion de guardar de los campos que contiene el modulo,
// conectado con el archivo principal "registrarempleados.php"

  $query = "INSERT INTO empleado (nombre_empleado, apellido, genero, direccion, salario, email, fecha_nacimiento, idcargo) VALUES ('$nombreempleado', '$apellidoempleado','$genero' ,'$direccion','$salario','$correo','$fecha', '$idcargo')";
  $result= mysqli_query($conn, $query);

  
// Se realiza consulta bajo la funcion INSERT INTO para ingresar los datos en los campos
  // que se necesitan para la tabla "empleado"
  if (!$result) {
   die('falló');
  }

  $_SESSION['message'] = 'Informacion registrada correctamente'; // mensaje que arroja al momento de que sea exitoso el ingreso de los nuevos registros
  $_SESSION['message_type'] = 'success'; // el tipo de mensaje que va a mostrar

header("location: ../principales/registrarempleados.php");
// redireccion al archivo principal del modulo "empleado"
}

?>