<body background="../Imagen/Fondo.jpg">
<?php
include("../principales/db.php");
include("../principales/nabvar.php");
// El codigo 2-4 me esta conectando con el archivo para la conexion a la base de datos y el nabvar


if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM empleado where idempleado = $id";
    $result= mysqli_query($conn, $query );
    if (mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $nombre = $row['nombre_empleado'];
        $apellido = $row['apellido'];
        $genero = $row['genero'];
        $direccion = $row['direccion'];
        $salario = $row['salario'];
        $email = $row['email'];
        $fecha= $row['fecha_nacimiento'];
        $idcargo = $row['idcargo'];
        
// En estas lineas de codigo estoy seleccionando la informacion de la tabla "empleados" de la base de datos
        // asignandole nombres privados a las caracteristicas que contiene la tabla y lo que se va a modificar
    }

}

if (isset($_POST['actualizar'])) {
    $id = $_GET['id'];
    $nombre= $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $genero = $_POST['genero'];
    $direccion = $_POST['direccion'];
    $salario = $_POST['salario'];
    $email = $_POST['email'];
    $fecha = $_POST['fecha'];
    $idcargo = $_POST['idcargo'];

    $query = "UPDATE empleado set nombre_empleado= '$nombre', apellido = '$apellido', genero = '$genero', direccion='$direccion', salario ='$salario', email ='$email', fecha_nacimiento ='$fecha', idcargo ='$idcargo' WHERE idempleado=$id";
  mysqli_query($conn, $query);
  $_SESSION['message'] = 'Informacion actualizada correctamente';
  $_SESSION['message_type'] = 'warning';
  header('Location: ../principales/registrarempleados.php');

    
    // Se realiza consulta bajo la condicion UPDATE para realizar el proceso en la tabla "cargos" 
    // y darle validez a la actualizacion


}


    


?>

<?php include('../includes/header.php'); ?>
<!-- Archivo que contiene el footer -->

<div class="container p-4">
  <div class="row">
    <div class="col-md-4 mx-auto">  
    <div class="card card-body">
    <form action="editeempleado.php?id=<?php echo $_GET['id']; ?>" method="POST">
    
    <div class="card card-body">
    <label class="form-label">Nombre empleado</label>
    <input name="nombre" type="text" class="form-control" value="<?php echo $nombre; ?>"
    class="form-control" placeholder="Actualice la informacion">
    </div>
    <div class="form-group">
    <div class="card card-body">
    <label class="form-label">Apellido</label>
        <textarea name="apellido" class="form-control"  placeholder="Actualice la informacion"  ><?php echo $apellido;?></textarea>
        </div>

        <div class="form-group">
        <div class="card card-body">
        <label class="form-label">Genero</label>
        <textarea name="genero" class="form-control" placeholder="Actualice la informacion" ><?php echo $genero;?></textarea>
        </div>

        <div class="form-group">
        <div class="card card-body">
        <label class="form-label">Direccion</label>
        <textarea name="direccion" class="form-control"  placeholder="Actualice la informacion"><?php echo $direccion;?></textarea>
        </div>
        <div class="form-group">
        <div class="card card-body">
        <label class="form-label">Salario</label>
        <textarea name="salario" class="form-control"  placeholder="Actualice la informacion"><?php echo $salario;?></textarea>
        </div>
        <div class="form-group">
        <div class="card card-body">
        <label class="form-label">Correo Electronico</label>
        <textarea name="email" class="form-control" placeholder="Actualice la informacion" ><?php echo $email;?></textarea>
        </div>
        <div class="form-group">
        <div class="card card-body">
        <label class="form-label">Fecha de nacimiento</label>
        <textarea name="fecha" class="form-control" placeholder="Actualice la informacion" ><?php echo $fecha;?></textarea>
        </div>
        <div class="form-group">
        <div class="card card-body">
        <label class="form-label">ID CARGO</label>
        <textarea name="idcargo" class="form-control"  placeholder="Actualice la informacion"><?php echo $idcargo;?></textarea>
        </div>
        <button class="btn btn-success" name="actualizar">
          Actualizar

          <!-- mediante estas lineas de codigo estoy generando una tarjeta con los campos que voy a actualizar -->

          </button>
      </form>
      </div>
    </div>
  </div>
</div>

<?php include('../includes/footer.php'); ?>
<!-- Archivo que contiene el footer -->