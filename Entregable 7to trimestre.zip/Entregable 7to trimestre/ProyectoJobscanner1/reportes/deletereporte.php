<?php

include("../principales/db.php");
// Se incluye archivo de la base de datos

if(isset($_GET['id'])) {
  $id = $_GET['id'];
  $query = "DELETE FROM mantenimiento WHERE idmantenimiento = $id";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }
// } consulta y proceso para ejecutar la funcion "DELETE" en la tabla "mantenimiento" para eliminar los registros seleccionados
  $_SESSION['message'] = 'Eliminado correctamente';
  $_SESSION['message_type'] = 'danger';
  header("Location: ../principales/registrarreporte.php");
    // me lleva al modulo principal de "registrar reportes"
}

?>
