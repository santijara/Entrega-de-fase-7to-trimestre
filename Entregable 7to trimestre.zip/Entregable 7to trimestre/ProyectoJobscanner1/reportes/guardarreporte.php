<?php

include("../principales/db.php");
// codigo que contiene la conexion con el archivo de la base de datos

if (isset($_POST['Reportar'])) {
  $fecha = $_POST["fecha"];
  $descripcion = $_POST["descripcion"];
  $idempleado = $_POST["idempleado"];
  $idmaquina = $_POST["idmaquina"];
  $tipo = $_POST["idtipo"];
// Mediante la funcion $_POST para ejecutar la opcion de guardar de los campos que contiene el modulo,
// conectado con el archivo principal "registrarreportes.php"

  $query = "INSERT INTO mantenimiento (fecha, descripcion, idempleado, idmaquina, idtipo) VALUES ('$fecha', '$descripcion','$idempleado', '$idmaquina','$tipo')";
  $result= mysqli_query($conn, $query);

  
  // Se realiza consulta bajo la funcion INSERT INTO para ingresar los datos en los campos
  // que se necesitan para la tabla "mantenimiento"

  if (!$result) {
   die('falló');
  }

  $_SESSION['message'] = 'Reporte guardado';
  $_SESSION['message_type'] = 'success';

header("location: ../principales/registrarreporte.php");
// redireccion al archivo principal del modulo "mantenimiento"

}

?>