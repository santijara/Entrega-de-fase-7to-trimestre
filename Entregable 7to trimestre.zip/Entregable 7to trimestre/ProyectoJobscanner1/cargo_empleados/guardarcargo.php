<?php

include("../principales/db.php");
// codigo que contiene la conexion con el archivo de la base de datos

if (isset($_POST['Guardar'])) {
  $nombrecargo = $_POST["nombrecargo"];
  $idarea = $_POST["idarea"];
  // Mediante la funcion $_POST para ejecutar la opcion de guardar de los campos que contiene el modulo,
// conectado con el archivo principal "registrarareamaq.php"

  $query = "INSERT INTO cargo (nombre_cargo, idarea) VALUES ('$nombrecargo','$idarea')";
  $result= mysqli_query($conn, $query);

  // Se realiza consulta bajo la funcion INSERT INTO para ingresar los datos en los campos
  // que se necesitan para la tabla "cargo"

  

  if (!$result) {
   die('falló');
  }

  $_SESSION['message'] = 'Cargo guardado';// mensaje que arroja al momento de que sea exitoso el ingreso de los nuevos registros
  $_SESSION['message_type'] = 'success';
    // el tipo de mensaje que va a mostrar

header("location: ../principales/registrarcargo.php");
// redireccion al archivo principal del modulo "registrarcargo.php"
}

?>