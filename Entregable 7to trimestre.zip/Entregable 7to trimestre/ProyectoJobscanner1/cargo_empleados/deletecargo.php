<?php

include("../principales/db.php");
// Se incluye archivo de la base de datos

if(isset($_GET['id'])) {
  $id = $_GET['id'];
  $query = "DELETE FROM cargo WHERE idcargo = $id";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
    // } consulta y proceso para ejecutar la funcion "DELETE" en la tabla "cargo" para eliminar los registros seleccionados

  }

  $_SESSION['message'] = 'Eliminado correctamente';
  // mensaje al momento de ejecutar la consulta
  $_SESSION['message_type'] = 'danger';
  // el tipo de alerta que deseo que aparezca
  header("Location: ../principales/registrarcargo.php");
  // me lleva al modulo principal de "area maquinas"
}
}

?>
