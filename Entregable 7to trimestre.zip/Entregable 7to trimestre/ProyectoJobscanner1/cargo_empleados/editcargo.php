<body background="../Imagen/Fondo.jpg">
<?php
include("../principales/db.php");
include("../principales/nabvar.php");
// El codigo 2-4 me esta conectando con el archivo para la conexion a la base de datos y el nabvar

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM cargo where idcargo = $id";
    $result= mysqli_query($conn, $query );
    if (mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $nombre = $row['nombre_cargo'];
        $idarea = $row['idarea'];

         // En estas lineas de codigo estoy seleccionando la informacion de la tabla "cargo" de la base de datos
        // asignandole nombres privados a las caracteristicas que contiene la tabla y lo que se va a modificar

        

    }

}

if (isset($_POST['actualizar'])) {
  // por medio del metodo POST el cual se llama del archivo principal para darle funcionalidad al boton y pueda realizar el cambio
    $id = $_GET['id'];
    $nombre= $_POST['nombre'];
    $idarea= $_POST['idarea'];

    $query = "UPDATE cargo set nombre_cargo = '$nombre', idarea ='$idarea' WHERE idcargo=$id";
  mysqli_query($conn, $query);
  $_SESSION['message'] = 'Informacion actualizada correctamente';
  $_SESSION['message_type'] = 'warning';
  header('Location: ../principales/registrarcargo.php');
  // Se realiza consulta bajo la condicion UPDATE para realizar el proceso en la tabla "cargos" 
    // y darle validez a la actualizacion


}


    


?>

<?php include('../includes/header.php'); ?>
<!-- Archivo que contiene el footer -->

<div class="container p-4">
  <div class="row">
    <div class="col-md-4 mx-auto">  
    <div class="card card-body">
    <form action="editcargo.php?id=<?php echo $_GET['id']; ?>" method="POST">
    <div class="form-group">
        <div class="card card-body">
        <label class="form-label">Nombre cargo</label>
    <input name="nombre" type="text" class="form-control" value="<?php echo $nombre; ?>"
    class="form-control" placeholder="Actualice la informacion">
    </div>

    <div class="form-group">
  
        <div class="card card-body">
        <label class="form-label">ID area</label>
    <input name="idarea" type="text" class="form-control" value="<?php echo $idarea; ?>"
    class="form-control" placeholder="Actualice la informacion">
    </div>
        <button class="btn btn-success" name="actualizar">
          Actualizar

           <!-- mediante estas lineas de codigo estoy generando una tarjeta con los campos que voy a actualizar -->

          </button>
      </form>
      </div>
    </div>
  </div>
</div>


