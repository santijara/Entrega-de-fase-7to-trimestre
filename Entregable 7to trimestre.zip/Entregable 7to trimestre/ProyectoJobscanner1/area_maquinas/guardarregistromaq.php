<?php

include("../principales/db.php");
// codigo que contiene la conexion con el archivo de la base de datos

if (isset($_POST['Guardar'])) {
  $nombreareamaq = $_POST["nombre"];
  $idmaquina = $_POST["maquina"];
// Mediante la funcion $_POST para ejecutar la opcion de guardar de los campos que contiene el modulo,
// conectado con el archivo principal "registrararea.php"

  $query = "INSERT INTO area_maquina(nombre, idmaquina) VALUES ('$nombreareamaq', '$idmaquina' )";
  $result= mysqli_query($conn, $query);
  
// Se realiza consulta bajo la funcion INSERT INTO para ingresar los datos en los campos
  // que se necesitan para la tabla "area"
  

  if (!$result) {
   die('falló');
  }

  $_SESSION['message'] = 'Area de las maquinas guardada'; // mensaje que arroja al momento de que sea exitoso el ingreso de los nuevos registros
  $_SESSION['message_type'] = 'success';
  // el tipo de mensaje que va a mostrar

header("location: ../principales/registrarareamaq.php");
// redireccion al archivo principal del modulo "registrarareamaq.php"

}

?>