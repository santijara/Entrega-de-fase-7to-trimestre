<body background="../Imagen/Fondo.jpg">
<?php
include("../principales/db.php");
include("../principales/nabvar.php");
// El codigo 2-4 me esta conectando con el archivo para la conexion a la base de datos y el nabvar

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM area_maquina where idareamaquina = $id";
    $result= mysqli_query($conn, $query );
    if (mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $nombreareamaq= $row['nombre'];
        $idmaquina= $row['idmaquina'];
       // En estas lineas de codigo estoy seleccionando la informacion de la tabla "area maquinas" de la base de datos
        // asignandole nombres privados a las caracteristicas que contiene la tabla y lo que se va a modificar
        

    }

}

if (isset($_POST['actualizar'])) {
  // por medio del metodo POST el cual se llama del archivo principal para darle funcionalidad al boton y pueda realizar el cambio
    $id = $_GET['id'];
    $nombreareamaq= $_POST['nombre'];
    $idmaquina= $_POST['maquina'];

    $query = "UPDATE area_maquina set nombre = '$nombreareamaq', idmaquina = '$idmaquina' WHERE idareamaquina=$id";
  mysqli_query($conn, $query);
  $_SESSION['message'] = 'Informacion actualizada correctamente';
  $_SESSION['message_type'] = 'warning';
  header('Location: ../principales/registrarareamaq.php');
  // Se realiza consulta bajo la condicion UPDATE para realizar el proceso en la tabla "area maquinas" 
    // y darle validez a la actualizacion

    
    


}


    


?>

<?php include('../includes/header.php'); ?>
<!-- Archivo que contiene el footer -->

<div class="container p-4">
  <div class="row">
    <div class="col-md-4 mx-auto">  
    <div class="card card-body">
    <form action="editeareamaq.php?id=<?php echo $_GET['id']; ?>" method="POST">
    <div class="form-group">
    <input name="nombre" type="text" class="form-control" value="<?php echo $nombreareamaq; ?>"
    class="form-control" placeholder="Actualice la informacion">
    </div>
    <br>
    <div class="form-group">
    <input name="maquina" type="text" class="form-control" value="<?php echo $idmaquina; ?>"
    class="form-control" placeholder="Actualice la informacion">
    </div>
    
        <button class="btn btn-success" name="actualizar">
          Actualizar

          <!-- mediante estas lineas de codigo estoy generando una tarjeta con los campos que voy a actualizar -->

          </button>
      </form>
      </div>
    </div>
  </div>
</div>

